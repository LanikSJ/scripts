export VISUAL=nano
export EDITOR=$VISUAL
export GEM_HOME="$HOME/.gems"
export PYTHONSTARTUP=~/.pythonrc
export HOMEBREW_NO_ANALYTICS=1
export CLICOLOR=1

export PAGER=less
export LESS='-i -N -w  -z-4 -g -e -M -X -F -R -P%t?f%f :stdin .?pb%pb\%:?lbLine %lb:?bbByte %bb:-...'
export LESS_TERMCAP_mb=$'\E[01;31m'
export LESS_TERMCAP_md=$'\E[01;36m'
export LESS_TERMCAP_me=$'\E[0m'
export LESS_TERMCAP_se=$'\E[0m'
export LESS_TERMCAP_so=$'\E[01;44;33m'
export LESS_TERMCAP_ue=$'\E[0m'
export LESS_TERMCAP_us=$'\E[01;32m'

export DOCKER_HOST=tcp://192.168.56.20:2375

# Ansible fixes
#export no_proxy="*"
export NO_PROXY="*"
export OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES

export QUOTING_STYLE=literal
export TZ="America/New_York"
export LANG="en_US.UTF-8"
export LC_ALL="en_US.UTF-8"
export BLOCKSIZE=1k
export VIRTUAL_ENV_DISABLE_PROMPT=1

# FIPS
#export env OPENSSL_FIPS=1
#export SSH_AUTH_SOCK="${HOME}/.ssh/.ssh_agent"

if ! pgrep -qf "ssh-agent -a $SSH_AUTH_SOCK" || [ ! -S "$SSH_AUTH_SOCK" ]; then
  rm -f "$SSH_AUTH_SOCK"
  eval "$(ssh-agent -a "$SSH_AUTH_SOCK")"
fi

eval "$(perl -I$HOME/perl5/lib/perl5 -Mlocal::lib=$HOME/perl5)"
eval "$(/usr/local/bin/brew shellenv)"
export PATH="$(brew --prefix)/opt/openssl-fips@3/bin:$PATH"
fipson() {
    sed -i '' 's/fips=no/fips=yes/' "$(brew --prefix)/etc/openssl-fips@3/openssl.cnf"
}

fipsoff() {
    sed -i '' 's/fips=yes/fips=no/' "$(brew --prefix)/etc/openssl-fips@3/openssl.cnf"
}
