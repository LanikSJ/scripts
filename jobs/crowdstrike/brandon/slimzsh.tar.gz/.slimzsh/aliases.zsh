# Detect which `ls` flavor is in use
if gls --color > /dev/null 2>&1; then
  colorflag="--color"
  export LS_COLORS='no=00:fi=00:di=01;31:ln=01;36:pi=40;33:so=01;35:do=01;35:bd=40;33;01:cd=40;33;01:or=40;31;01:ex=01;32:*.tar=01;31:*.tgz=01;31:*.arj=01;31:*.taz=01;31:*.lzh=01;31:*.zip=01;31:*.z=01;31:*.Z=01;31:*.gz=01;31:*.bz2=01;31:*.deb=01;31:*.rpm=01;31:*.jar=01;31:*.jpg=01;35:*.jpeg=01;35:*.gif=01;35:*.bmp=01;35:*.pbm=01;35:*.pgm=01;35:*.ppm=01;35:*.tga=01;35:*.xbm=01;35:*.xpm=01;35:*.tif=01;35:*.tiff=01;35:*.png=01;35:*.mov=01;35:*.mpg=01;35:*.mpeg=01;35:*.avi=01;35:*.fli=01;35:*.gl=01;35:*.dl=01;35:*.xcf=01;35:*.xwd=01;35:*.ogg=01;35:*.mp3=01;35:*.wav=01;35:'
else # macOS `ls`
  colorflag="-G"
  export LSCOLORS='BxBxhxDxfxhxhxhxhxcxcx'
fi

# updating
alias brewdate='brew update && brew upgrade; brew cleanup --prune=7'
alias pip3update='pip3 list --outdated --format=freeze | grep -v '^\-e' | cut -d = -f 1  | xargs -n1 pip3 install -U'

# gls -> ls
alias lsd="gls -lF ${colorflag} | grep --color=never '^d'"
alias ls='gls -F ${colorflag}'

# grep color
alias grep='grep --color=auto'
alias fgrep='fgrep --color=auto'
alias egrep='egrep --color=auto'

# utility
alias sudo='sudo '
alias cleanup="gfind . -type f -name '*.DS_Store' -ls -delete -print"
alias reload="exec ${SHELL} -l"
alias path='echo -e ${PATH//:/\\n}'
alias flushdns='sudo dscacheutil -flushcache; sudo killall -HUP mDNSResponder'
alias python=python3
#alias ssh="TERM=xterm-256color ssh"
# alias timejson='/usr/local/bin/gtime -f '"'"'{"exit_code" : %x, "time_user_seconds" : %U, "time_system_seconds" : %S, "time_wall_clock_seconds" : %e, "rss_max_kbytes" : %M, "rss_avg_kbytes" : %t, "page_faults_major" : %F, "page_faults_minor" : %R, "io_inputs" : %I, "io_outputs" : %O, "context_switches_voluntary" : %w, "context_switches_involuntary" : %c, "cpu_percentage" : "%P", "signals_received" : %k}'"'"
# alias wifi='/System/Library/PrivateFrameworks/Apple80211.framework/Versions/A/Resources/airport'

_lsp() {
  if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    ls_bin=/bin/ls
    awk_bin=/usr/bin/awk
  elif [[ "$OSTYPE" == "darwin"* ]]; then
    ls_bin=/usr/local/bin/gls
    awk_bin=/usr/local/bin/gawk
  fi
  ( ${ls_bin} -alG --color "$@" ) | \
  ( ${awk_bin} '{k=0;for(i=0;i<=8;i++)k+=((substr($1,i+2,1)~/[rwx]/)*2^(8-i));if(k)printf(" (%0o) ",k);print}' );
}
alias lsp=_lsp
