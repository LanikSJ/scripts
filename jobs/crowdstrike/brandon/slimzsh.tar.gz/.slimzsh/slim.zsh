slim_path=`dirname $0`
fpath=( $slim_path/funcs $slim_path $fpath )
autoload -U $fpath[1]/*(.:t)

themes=('nicoulaj' 'steeef' 'ys' 'apollo-zsh-theme')

for t in $themes; do
  fpath+=$slim_path/themes/$t
done

autoload -U promptinit && promptinit
# prompt ys
prompt steeef
# prompt pure

autoload bashcompinit && bashcompinit
autoload -U compinit
compinit -i

setopt autocd
setopt extendedglob
setopt NO_NOMATCH

#source $slim_path/env.zsh
source $slim_path/path.zsh
source $slim_path/plugins.zsh
source $slim_path/keys.zsh
source $slim_path/history.zsh
source $slim_path/completion.zsh
source $slim_path/aliases.zsh
source $slim_path/correction.zsh
source $slim_path/stack.zsh
source $slim_path/fast-syntax-highlighting/fast-syntax-highlighting.plugin.zsh
source $slim_path/env.zsh

if command -v fasd >/dev/null 2>&1; then
  eval "$(fasd --init zsh-hook zsh-ccomp zsh-ccomp-install zsh-wcomp zsh-wcomp-install posix-alias)"
fi

