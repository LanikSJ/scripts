has_PATH () {
    local tmp=":$PATH:"
    [ "${tmp}" != "${tmp#*:$1:}" ]
}

prepend_PATH () {
    has_PATH "$1" || PATH="$1:$PATH"
}

append_PATH () {
    has_PATH "$1" || PATH="$PATH:$1"
}

prepend=(
    '/usr/local/bin'
    '/usr/local/sbin'
)

append=(
    '/Users/bgeyerlopez/bin'
    '/Users/bgeyerlopez/.local/bin'
    '/Users/bgeyerlopez/go/bin'
)

for i in $prepend; do
  prepend_PATH "$i"
done

for i in $append; do
  append_PATH "$i"
done

NPM_PACKAGES="${HOME}/.npm-packages"
path+=("${NPM_PACKAGES}/bin")
export MANPATH="${MANPATH-$(manpath)}:$NPM_PACKAGES/share/man"

export WORKON_HOME=$HOME/.virtualenvs
export PROJECT_HOME=$HOME/.projects
export VIRTUALENVWRAPPER_PYTHON=/usr/local/bin/python3
export VIRTUALENVWRAPPER_VIRTUALENV=/usr/local/bin/virtualenv
source /usr/local/bin/virtualenvwrapper.sh
